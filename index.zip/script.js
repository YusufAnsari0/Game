function openGame(gameUrl) {
    window.location.href = gameUrl;
}
