// Main Game Variables
const board = document.getElementById('game-board');
const scoreDisplay = document.getElementById('score');
const gameOverMessage = document.getElementById('game-over-message');
const startButton = document.getElementById('start-button');

const BOARD_SIZE = 20;
const SPEED = 200;
let snake = [{ x: 10, y: 10 }];
let direction = { x: 0, y: 0 }; // Snake starts stationary
let food = getRandomFoodPosition();
let score = 0;
let gameRunning = false;
let started = false;

// Create the game board
function createBoard() {
    board.innerHTML = '';
    for (let i = 0; i < BOARD_SIZE * BOARD_SIZE; i++) {
        const cell = document.createElement('div');
        cell.classList.add('cell');
        board.appendChild(cell);
    }
}

function resetGame() {
    snake = [{ x: 10, y: 10 }]; // Start snake in the middle of the board
    direction = { x: 1, y: 0 }; // Start moving right
    food = getRandomFoodPosition(); // Random food position

    score = 0;
    gameRunning = false;
    started = false;

    scoreDisplay.textContent = `Score: ${score}`;
    gameOverMessage.style.display = 'none';

    createBoard(); // Re-draw the board
    draw(); // Render snake and food
}

// End the game
function endGame() {
    gameRunning = false;
    gameOverMessage.style.display = 'block';
}

function checkCollision(head) {
    return (
        head.x < 0 || head.x >= BOARD_SIZE || // Check wall collision
        head.y < 0 || head.y >= BOARD_SIZE || // Check wall collision
        snake.some(segment => segment.x === head.x && segment.y === head.y) // Check self-collision
    );
}

// Update snake's position
function updateSnake() {
    if (!gameRunning) return;

    const newHead = {
        x: snake[0].x + direction.x,
        y: snake[0].y + direction.y,
    };

    if (checkCollision(newHead)) {
        endGame();
        return;
    }

    snake.unshift(newHead);
    if (newHead.x === food.x && newHead.y === food.y) {
        score++;
        scoreDisplay.textContent = `Score: ${score}`;
        food = getRandomFoodPosition();
    } else {
        snake.pop();
    }
}

function draw() {
    createBoard();
    const cells = document.querySelectorAll('.cell');

    console.log("Snake Cells:", snake);
    console.log("Food Cell:", food);

    snake.forEach((segment, index) => {
        const cellIndex = segment.y * BOARD_SIZE + segment.x;
        cells[cellIndex].classList.add('snake');
        if (index === 0) cells[cellIndex].classList.add('snake-head');
    });

    const foodIndex = food.y * BOARD_SIZE + food.x;
    cells[foodIndex].classList.add('food');
}


// Generate random food position ensuring no collision with the snake
function getRandomFoodPosition() {
    let position;
    do {
        position = {
            x: Math.floor(Math.random() * BOARD_SIZE),
            y: Math.floor(Math.random() * BOARD_SIZE),
        };
    } while (snake.some(segment => segment.x === position.x && segment.y === position.y));
    return position;
}

// Game Loop
function gameLoop() {
    if (gameRunning && started) {
        updateSnake();
        draw();
        setTimeout(gameLoop, SPEED);
    }
}

// Handle keyboard input
document.addEventListener('keydown', (e) => {
    if (!started) {
        started = true;
        gameRunning = true;
        gameLoop();
    }

    if (!gameRunning) return;

    const newDirection = { ...direction };
    switch (e.key) {
        case 'ArrowUp':
            if (direction.y === 0) newDirection.x = 0, newDirection.y = -1;
            break;
        case 'ArrowDown':
            if (direction.y === 0) newDirection.x = 0, newDirection.y = 1;
            break;
        case 'ArrowLeft':
            if (direction.x === 0) newDirection.x = -1, newDirection.y = 0;
            break;
        case 'ArrowRight':
            if (direction.x === 0) newDirection.x = 1, newDirection.y = 0;
            break;
    }

    const nextHead = {
        x: snake[0].x + newDirection.x,
        y: snake[0].y + newDirection.y,
    };

    if (!checkCollision(nextHead)) {
        direction = newDirection;
    }
});

// Touch controls
['up', 'left', 'down', 'right'].forEach(dir => {
    document.getElementById(dir).addEventListener('click', () => {
        if (!started) {
            started = true;
            gameRunning = true;
            gameLoop();
        }

        if (!gameRunning) return;

        let newDirection = { ...direction };
        switch (dir) {
            case 'up':
                if (direction.y === 0) newDirection = { x: 0, y: -1 };
                break;
            case 'down':
                if (direction.y === 0) newDirection = { x: 0, y: 1 };
                break;
            case 'left':
                if (direction.x === 0) newDirection = { x: -1, y: 0 };
                break;
            case 'right':
                if (direction.x === 0) newDirection = { x: 1, y: 0 };
                break;
        }

        const nextHead = {
            x: snake[0].x + newDirection.x,
            y: snake[0].y + newDirection.y,
        };

        if (!checkCollision(nextHead)) {
            direction = newDirection;
        }
    });
});

// Start button functionality
startButton.addEventListener('click', resetGame);

function isGameOver() {
    console.log("Checking game over...");
    console.log("Snake Head Position:", snake[0]);
    console.log("Snake Body:", snake);

    for (let i = 1; i < snake.length; i++) {
        if (snake[i].x === snake[0].x && snake[i].y === snake[0].y) {
            console.log("Collision with self detected.");
            return true;
        }
    }

    if (
        snake[0].x < 0 || snake[0].x >= BOARD_SIZE ||
        snake[0].y < 0 || snake[0].y >= BOARD_SIZE
    ) {
        console.log("Out of bounds detected.");
        return true;
    }

    return false;
}

function startGame() {
    if (gameRunning) return; // Prevent multiple starts
    resetGame();
    gameRunning = true;
    started = true;

    console.log("Game started. Initial snake:", snake);
    console.log("Initial food position:", food);

    gameLoop = setInterval(() => {
        update();
        draw();

        if (isGameOver()) {
            clearInterval(gameLoop);
            document.querySelector('#game-over-message').style.display = 'block';
            console.log("Game Over.");
        }
    }, 200); // Adjust speed as needed
}

function update() {
    console.log("Updating game...");
    
    const head = { x: snake[0].x + direction.x, y: snake[0].y + direction.y };

    if (isGameOver()) {
        console.log("Collision detected during update.");
        return;
    }

    snake.unshift(head);

    if (head.x === food.x && head.y === food.y) {
        score++;
        document.querySelector('#score').textContent = `Score: ${score}`;
        food = getRandomFoodPosition();
    } else {
        snake.pop(); // Remove the last segment
    }
}
