// Variables
const boardSize = 4; // 4x4 board
let board = [];
let score = 0;
let gameOver = false;

const boardElement = document.getElementById("board");
const scoreElement = document.getElementById("score");
const gameOverOverlay = document.getElementById("game-over");

// Initialize game
function initializeGame() {
  // Reset board and score
  board = Array(boardSize).fill().map(() => Array(boardSize).fill(0));
  score = 0;
  gameOver = false;
  scoreElement.textContent = score;

  // Hide the game-over overlay
  gameOverOverlay.style.display = "none";

  // Clear the board
  boardElement.innerHTML = "";

  // Create the grid and tiles
  for (let i = 0; i < boardSize; i++) {
    for (let j = 0; j < boardSize; j++) {
      const tile = document.createElement("div");
      tile.classList.add("tile");
      tile.setAttribute("data-x", i);
      tile.setAttribute("data-y", j);
      boardElement.appendChild(tile);
    }
  }

  // Add initial tiles
  addRandomTile();
  addRandomTile();
}

// Add a random tile to the board (either 2 or 4)
function addRandomTile() {
  if (gameOver) return;

  let emptyCells = [];
  for (let i = 0; i < boardSize; i++) {
    for (let j = 0; j < boardSize; j++) {
      if (board[i][j] === 0) {
        emptyCells.push({ x: i, y: j });
      }
    }
  }

  if (emptyCells.length === 0) return;

  const randomIndex = Math.floor(Math.random() * emptyCells.length);
  const { x, y } = emptyCells[randomIndex];
  const value = Math.random() < 0.9 ? 2 : 4;
  board[x][y] = value;

  const tile = document.querySelector(`[data-x="${x}"][data-y="${y}"]`);
  tile.textContent = value;
  tile.setAttribute("data-value", value);
  tile.style.background = getTileBackground(value);
}

// Get tile background color based on value
function getTileBackground(value) {
  switch (value) {
    case 2: return "linear-gradient(135deg, #ffecd2, #fcb69f)";
    case 4: return "linear-gradient(135deg, #ff9a9e, #fad0c4)";
    case 8: return "linear-gradient(135deg, #ff758c, #ff7eb3)";
    case 16: return "linear-gradient(135deg, #fbc2eb, #a6c1ee)";
    case 32: return "linear-gradient(135deg, #84fab0, #8fd3f4)";
    case 64: return "linear-gradient(135deg, #8e2de2, #4a00e0)";
    case 128: return "linear-gradient(135deg, #fa709a, #fee140)";
    case 256: return "linear-gradient(135deg, #30cfd0, #330867)";
    case 512: return "linear-gradient(135deg, #d4fc79, #96e6a1)";
    case 1024: return "linear-gradient(135deg, #a18cd1, #fbc2eb)";
    case 2048: return "linear-gradient(135deg, #ffe259, #ffa751)";
    default: return "#cdc1b4";
  }
}

// Handle swipe and combine tiles logic (simplified)
document.addEventListener("keydown", (e) => {
  if (gameOver) return;

  if (e.key === "ArrowUp") moveTiles("up");
  if (e.key === "ArrowDown") moveTiles("down");
  if (e.key === "ArrowLeft") moveTiles("left");
  if (e.key === "ArrowRight") moveTiles("right");

  addRandomTile();
  updateBoard();
  checkGameOver();
});

// Move tiles in a specific direction (simplified)
function moveTiles(direction) {
  let rotatedBoard;

  switch (direction) {
    case "up":
      rotatedBoard = rotateBoardCounterClockwise(board);
      break;
    case "down":
      rotatedBoard = rotateBoardClockwise(board);
      break;
    case "left":
      rotatedBoard = board;
      break;
    case "right":
      rotatedBoard = rotateBoardClockwise(rotateBoardClockwise(board));
      break;
    default:
      return;
  }

  const newBoard = slideAndCombine(rotatedBoard);
  if (direction === "up") {
    board = rotateBoardClockwise(newBoard);
  } else if (direction === "down") {
    board = rotateBoardCounterClockwise(newBoard);
  } else if (direction === "right") {
    board = rotateBoardClockwise(rotateBoardClockwise(newBoard));
  } else {
    board = newBoard;
  }
}

// Rotate the board 90 degrees clockwise
function rotateBoardClockwise(board) {
  return board[0].map((_, i) => board.map(row => row[i])).reverse();
}

// Rotate the board 90 degrees counter-clockwise
function rotateBoardCounterClockwise(board) {
  return board[0].map((_, i) => board.map(row => row[i])).reverse().reverse();
}

// Slide and combine tiles in one move (simplified)
function slideAndCombine(board) {
  let newBoard = board.map(row => row.filter(val => val !== 0)); // Remove all zeros
  newBoard = newBoard.map(row => {
    // Combine tiles when possible
    let newRow = [];
    let i = 0;
    while (i < row.length) {
      if (row[i] === row[i + 1]) {
        newRow.push(row[i] * 2);
        score += row[i] * 2; // Add to score
        i += 2; // Skip the next tile
      } else {
        newRow.push(row[i]);
        i++;
      }
    }
    return newRow.concat(Array(boardSize - newRow.length).fill(0)); // Add zeros at the end
  });

  return newBoard;
}

// Update board visuals
function updateBoard() {
  for (let i = 0; i < boardSize; i++) {
    for (let j = 0; j < boardSize; j++) {
      const tile = document.querySelector(`[data-x="${i}"][data-y="${j}"]`);
      const value = board[i][j];
      tile.textContent = value === 0 ? "" : value;
      tile.setAttribute("data-value", value);
      tile.style.background = getTileBackground(value);
    }
  }

  scoreElement.textContent = score;
}

// Check if the game is over
function checkGameOver() {
  if (isBoardFull() && !canMove()) {
    gameOver = true;
    gameOverOverlay.style.display = "flex"; // Show game over screen
  }
}

// Check if there are any empty spaces left
function isBoardFull() {
  for (let i = 0; i < boardSize; i++) {
    for (let j = 0; j < boardSize; j++) {
      if (board[i][j] === 0) {
        return false;
      }
    }
  }
  return true;
}

// Check if a move is possible (if there are adjacent tiles that can combine)
function canMove() {
  for (let i = 0; i < boardSize; i++) {
    for (let j = 0; j < boardSize; j++) {
      if (board[i][j] === 0) return true;
      if (i < boardSize - 1 && board[i][j] === board[i + 1][j]) return true;
      if (j < boardSize - 1 && board[i][j] === board[i][j + 1]) return true;
    }
  }
  return false;
}

// Start the game when the page loads
initializeGame();

let startX, startY, endX, endY;

// Detect touch start
document.addEventListener("touchstart", (e) => {
  const touch = e.touches[0];
  startX = touch.clientX;
  startY = touch.clientY;
});

// Detect touch end and determine swipe direction
document.addEventListener("touchend", (e) => {
  const touch = e.changedTouches[0];
  endX = touch.clientX;
  endY = touch.clientY;

  const deltaX = endX - startX;
  const deltaY = endY - startY;

  if (Math.abs(deltaX) > Math.abs(deltaY)) {
    // Horizontal swipe
    if (deltaX > 30) moveTiles("right");
    if (deltaX < -30) moveTiles("left");
  } else {
    // Vertical swipe
    if (deltaY > 30) moveTiles("down");
    if (deltaY < -30) moveTiles("up");
  }

  addRandomTile();
  updateBoard();
  checkGameOver();
});

