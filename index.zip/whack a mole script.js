const holes = document.querySelectorAll('.hole');
const scoreDisplay = document.getElementById('score');
const startButton = document.getElementById('startButton');

let score = 0;
let bombHits = 0;
let timeUp = false;
let moleInterval;
let bombInterval;

function randomTime(min, max) {
  return Math.round(Math.random() * (max - min) + min);
}

function randomHole(holes) {
  const index = Math.floor(Math.random() * holes.length);
  return holes[index];
}

function isHoleOccupied(hole) {
  return hole.querySelector('.mole') || hole.querySelector('.bomb');
}

function showMole() {
  const hole = randomHole(holes);
  if (isHoleOccupied(hole)) return;

  const mole = document.createElement('div');
  mole.classList.add('mole');
  
  // Create the eyes
  const eyes = document.createElement('div');
  eyes.classList.add('eyes');

  const leftEye = document.createElement('div');
  leftEye.classList.add('eye');
  const rightEye = document.createElement('div');
  rightEye.classList.add('eye');

  eyes.appendChild(leftEye);
  eyes.appendChild(rightEye);

  // Create the nose
  const nose = document.createElement('div');
  nose.classList.add('nose');

  // Create the teeth
  const teeth = document.createElement('div');
  teeth.classList.add('teeth');

  const leftTooth = document.createElement('div');
  leftTooth.classList.add('tooth');
  const rightTooth = document.createElement('div');
  rightTooth.classList.add('tooth');

  teeth.appendChild(leftTooth);
  teeth.appendChild(rightTooth);

  // Append facial features to the mole
  mole.appendChild(eyes);
  mole.appendChild(nose);
  mole.appendChild(teeth);
  
  // Scale mole properly within its parent container
  mole.style.width = '70%';
  mole.style.height = '80%';
  
  mole.addEventListener('pointerdown', () => {
    score++;
    scoreDisplay.textContent = score;
    mole.remove();
  });

  hole.appendChild(mole);

  setTimeout(() => {
    mole.remove();
  }, 1500);
}

function showBomb() {
  const hole = randomHole(holes);
  if (isHoleOccupied(hole)) return;

  const bomb = document.createElement('div');
  bomb.classList.add('bomb');
  
  // Scale bomb properly within its parent container
  bomb.style.width = '60%';
  bomb.style.height = '60%';

  bomb.addEventListener('pointerdown', () => {
    bombHits++;
    score -= 5;
    scoreDisplay.textContent = score;
    bomb.remove();

    if (bombHits >= 3) {
      gameOver();
    }
  });

  hole.appendChild(bomb);

  setTimeout(() => {
    bomb.remove();
  }, randomTime(1500, 2500));
}

function gameOver() {
  timeUp = true;
  stopGame();

  const popup = document.createElement('div');
  popup.classList.add('popup');
  popup.innerHTML = `
    <h2>Game Over!</h2>
    <p>Your final score: ${score}</p>
    <button id="restartButton">Restart</button>
    <p class="credits">Made By - Yusuf Ansari</p>
  `;
  document.body.appendChild(popup);

  const restartButton = document.getElementById('restartButton');
  restartButton.addEventListener('pointerdown', () => {
    popup.remove();
    startGame();
  });
}

function stopGame() {
  clearInterval(moleInterval);
  clearInterval(bombInterval);
  document.querySelectorAll('.mole, .bomb').forEach(el => el.remove());
}

function startGame() {
  score = 0;
  bombHits = 0;
  scoreDisplay.textContent = score;
  timeUp = false;

  moleInterval = setInterval(showMole, 1000);
  bombInterval = setInterval(showBomb, 2000);
}

function startGameHandler(event) {
  event.preventDefault();
  startGame();
  
  // Disable start button temporarily to avoid multiple triggers
  startButton.disabled = true;

  // Re-enable start button after a slight delay
  setTimeout(() => {
    startButton.disabled = false;
  }, 500);
}

// Use pointerdown for broader compatibility
startButton.addEventListener('pointerdown', startGameHandler);
