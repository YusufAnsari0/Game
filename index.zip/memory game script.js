let cards = [];
let flippedCards = [];
let matchedPairs = 0;
let currentPlayer = 1; // 1 = Player, 2 = Computer
let scores = [0, 0];
let currentGameMode = '';

function startSinglePlayer() {
  currentGameMode = 'single';
  startGame();
}

function startFriendGame() {
  currentGameMode = 'friend';
  startGame();
}

function startComputerGame() {
  currentGameMode = 'computer';
  startGame();
}

function startGame() {
  // Hide all other sections and show the game board and scoreboard
  document.getElementById('game-options').classList.add('hidden');
  document.getElementById('gameBoard').classList.remove('hidden');
  document.getElementById('scoreboard').classList.remove('hidden');
  document.getElementById('game-end-options').classList.add('hidden');

  // Generate and shuffle cards
  const cardValues = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', '1', '2', '3', '4', '5', '@', '&', '$', '#', '%'];
  const selectedValues = [];
  while (selectedValues.length < 8) {
    const randomValue = cardValues[Math.floor(Math.random() * cardValues.length)];
    if (!selectedValues.includes(randomValue)) {
      selectedValues.push(randomValue);
    }
  }
  const shuffledValues = [...selectedValues, ...selectedValues].sort(() => Math.random() - 0.5);

  cards = shuffledValues.map((value, index) => {
    const card = document.createElement('div');
    card.classList.add('card');
    card.dataset.index = index;
    card.dataset.value = value;
    card.innerHTML = `
      <div class="card-inner">
        <div class="card-front"></div>
        <div class="card-back">${value}</div>
      </div>
    `;
    card.addEventListener('click', () => {
      if (currentGameMode !== 'computer' || currentPlayer === 1) {
        flipCard(card);
      }
    });
    return card;
  });

  const gameBoard = document.getElementById('gameBoard');
  gameBoard.innerHTML = '';
  cards.forEach(card => gameBoard.appendChild(card));

  // Reset game state
  matchedPairs = 0;
  flippedCards = [];
  currentPlayer = 1;
  scores = [0, 0];
  updateScoreBoard();
}

function flipCard(card) {
  if (flippedCards.length === 2 || card.classList.contains('flipped')) return;

  card.classList.add('flipped');
  flippedCards.push(card);

  if (flippedCards.length === 2) {
    checkMatch();
  }
}

function checkMatch() {
  const [card1, card2] = flippedCards;
  const card1Value = card1.dataset.value;
  const card2Value = card2.dataset.value;

  if (card1Value === card2Value) {
    matchedPairs++;
    scores[currentPlayer - 1]++;
    flippedCards = [];
    if (matchedPairs === cards.length / 2) {
      endGame();
    } else if (currentGameMode === 'computer' && currentPlayer === 2) {
      setTimeout(makeComputerMove, 1000);
    }
  } else {
    setTimeout(() => {
      flippedCards.forEach(card => card.classList.remove('flipped'));
      flippedCards = [];
      if (currentGameMode === 'friend') {
        currentPlayer = currentPlayer === 1 ? 2 : 1;
      } else if (currentGameMode === 'computer') {
        currentPlayer = currentPlayer === 1 ? 2 : 1;
        if (currentPlayer === 2) {
          setTimeout(makeComputerMove, 1000);
        }
      }
    }, 1000);
  }
  updateScoreBoard();
}

function updateScoreBoard() {
  const scoreboard = document.getElementById('scoreboard');
  if (currentGameMode === 'friend') {
    scoreboard.textContent = `Player 1: ${scores[0]} | Player 2: ${scores[1]} | Current Turn: Player ${currentPlayer}`;
  } else if (currentGameMode === 'computer') {
    scoreboard.textContent = `You: ${scores[0]} | Computer: ${scores[1]}${currentPlayer === 2 ? ' | Computer is thinking...' : ''}`;
  } else {
    scoreboard.textContent = `Score: ${scores[0]}`;
  }
}

function makeComputerMove() {
  const unflippedCards = cards.filter(card => !card.classList.contains('flipped'));

  if (unflippedCards.length < 2) return;

  // Randomly select two cards for the computer
  const randomIndexes = unflippedCards
    .map((card, index) => index)
    .sort(() => Math.random() - 0.5)
    .slice(0, 2);

  const card1 = unflippedCards[randomIndexes[0]];
  const card2 = unflippedCards[randomIndexes[1]];

  card1.classList.add('flipped');
  flippedCards.push(card1);

  setTimeout(() => {
    card2.classList.add('flipped');
    flippedCards.push(card2);

    checkMatch();
  }, 1000);
}

function endGame() {
    // Hide the game board
    document.getElementById('gameBoard').classList.add('hidden');

    // Show the game-end-options section
    const gameEndOptions = document.getElementById('game-end-options');
    gameEndOptions.classList.remove('hidden');
    gameEndOptions.style.display = 'block'; // Ensure it is visible

    // Update the result message
    const result = document.getElementById('result');
    if (currentGameMode === 'friend') {
        if (scores[0] > scores[1]) {
            result.textContent = 'Player 1 Wins!';
        } else if (scores[1] > scores[0]) {
            result.textContent = 'Player 2 Wins!';
        } else {
            result.textContent = "It's a Draw!";
        }
    } else if (currentGameMode === 'computer') {
        result.textContent = scores[0] > scores[1] ? 'You Win!' : 'Computer Wins!';
    } else {
        result.textContent = 'Game Over!';
    }
}


function startNewGame() {
  startGame();
}

function showGameOptions() {
  document.getElementById('game-options').classList.remove('hidden');
  document.getElementById('game-end-options').classList.add('hidden');
}

function exitGame() {
  window.location.reload();
}
