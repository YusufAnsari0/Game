const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const replayBtn = document.getElementById("replayBtn");

// Set smaller canvas dimensions
canvas.width = 600; // Smaller width
canvas.height = 400; // Smaller height

// Game variables
let x, y, dx, dy;
let paddleHeight = 10; // Increased paddle height
let paddleWidth = 85; // Increased paddle width
let paddleX;
let rightPressed = false;
let leftPressed = false;
let brickRowCount = 4;
let brickColumnCount = 6; // Increased brick columns
let brickWidth = 70;
let brickHeight = 20;
let brickPadding = 10;
let brickOffsetTop = 50; // Adjusted vertical offset
let brickOffsetLeft = 65; // Adjusted horizontal offset
let score;
let bricks;
let isAnimating = false;
let isGameOver = false;
let ballRadius = 20;  // Increased ball size
dx = 3;  // Slower horizontal speed
dy = -3; // Slower vertical speed

// Animation variables
let descentAnimation = {
    active: false,
    frames: 30,
    currentFrame: 0,
    rowToDescend: -1,
};

// Initialize game state
function initializeGameState() {
    x = canvas.width / 2;
    y = canvas.height - 40; // Adjusted for larger canvas
    dx = 3; // Increased speed
    dy = -3; // Increased speed
    paddleX = (canvas.width - paddleWidth) / 2;
    score = 0;
    isGameOver = false;
    initializeBricks();
}

// Initialize bricks with gradient colors
function initializeBricks() {
    bricks = [];
    for (let r = 0; r < brickRowCount; r++) {
        bricks[r] = [];
        for (let c = 0; c < brickColumnCount; c++) {
            bricks[r][c] = { status: 1 };
        }
    }
}

// Event listeners for key presses
document.addEventListener("keydown", (e) => {
    if (e.key === "ArrowRight" || e.key === "Right") rightPressed = true;
    else if (e.key === "ArrowLeft" || e.key === "Left") leftPressed = true;
});

document.addEventListener("keyup", (e) => {
    if (e.key === "ArrowRight" || e.key === "Right") rightPressed = false;
    else if (e.key === "ArrowLeft" || e.key === "Left") leftPressed = false;
});

let backgroundOffset = 0; // Add scrolling effect

function drawBackground() {
    const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    gradient.addColorStop(0, "#001F3F");
    gradient.addColorStop(0.5, "#003B6F");
    gradient.addColorStop(1, "#005B9F");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Moving background effect (subtle)
    backgroundOffset += 0.1; // Speed of the effect
    ctx.fillStyle = "rgba(255, 255, 255, 0.1)";
    ctx.fillRect(backgroundOffset, 0, canvas.width, canvas.height);
    if (backgroundOffset > canvas.width) backgroundOffset = 0; // Loop back
}


// Draw bricks with updated dimensions
function drawBricks() {
    for (let r = 0; r < brickRowCount; r++) {
        for (let c = 0; c < brickColumnCount; c++) {
            if (bricks[r][c].status === 1) {
                let brickX = c * (brickWidth + brickPadding) + brickOffsetLeft;
                let brickY =
                    r * (brickHeight + brickPadding) + brickOffsetTop +
                    (descentAnimation.active
                        ? (descentAnimation.currentFrame * (brickHeight + brickPadding)) / descentAnimation.frames
                        : 0);

                // Create a new gradient for each brick
                const brickGradient = ctx.createLinearGradient(brickX, brickY, brickX + brickWidth, brickY + brickHeight);

                // Assign unique colors based on both row and column
                if (c % 3 === 0) {
                    brickGradient.addColorStop(0, `#FF5F7E`); // Bright pink
                    brickGradient.addColorStop(1, `#FF7EB3`); // Soft neon pink
                } else if (c % 3 === 1) {
                    brickGradient.addColorStop(0, `#58FAAC`); // Bright mint green
                    brickGradient.addColorStop(1, `#00FFA3`); // Neon green
                } else {
                    brickGradient.addColorStop(0, `#FFD700`); // Bright yellow
                    brickGradient.addColorStop(1, `#FFA500`); // Neon orange
                }

                ctx.beginPath();
                ctx.roundRect(brickX, brickY, brickWidth, brickHeight, 5);
                ctx.fillStyle = brickGradient;
                ctx.fill();
                ctx.closePath();
            }
        }
    }
}

// Collision detection
function collisionDetection() {
    for (let r = 0; r < brickRowCount; r++) {
        for (let c = 0; c < brickColumnCount; c++) {
            let b = bricks[r][c];
            if (b.status === 1) {
                let brickX = c * (brickWidth + brickPadding) + brickOffsetLeft;
                let brickY = r * (brickHeight + brickPadding) + brickOffsetTop;

                if (
                    x + ballRadius > brickX &&
                    x - ballRadius < brickX + brickWidth &&
                    y + ballRadius > brickY &&
                    y - ballRadius < brickY + brickHeight
                ) {
                    dy = -dy;
                    b.status = 0;
                    score++;
                    handleRowClear();
                }
            }
        }
    }
}

// Check for cleared rows
function handleRowClear() {
    for (let r = brickRowCount - 1; r >= 0; r--) {
        let rowCleared = true;

        for (let c = 0; c < brickColumnCount; c++) {
            if (bricks[r][c].status === 1) {
                rowCleared = false;
                break;
            }
        }

        // Trigger descent animation if a row is cleared
        if (rowCleared) {
            descentAnimation.active = true;
            descentAnimation.rowToDescend = r;
            descentAnimation.currentFrame = 0;
        }
    }
}

// Animate row descent
function animateDescent() {
    if (descentAnimation.active) {
        descentAnimation.currentFrame++;
        if (descentAnimation.currentFrame >= descentAnimation.frames) {
            for (let r = descentAnimation.rowToDescend; r > 0; r--) {
                bricks[r] = [...bricks[r - 1]];
            }
            initializeTopRow();
            descentAnimation.active = false;
        }
    }
}

// Initialize a new row at the top
function initializeTopRow() {
    const topRow = [];
    for (let c = 0; c < brickColumnCount; c++) {
        topRow[c] = { status: 1 };
    }
    bricks[0] = topRow;
}

function drawBall() {
    ctx.beginPath();
    ctx.arc(x, y, ballRadius, 0, Math.PI * 2);
    ctx.fillStyle = "#FFFFFF";
    ctx.shadowColor = "#999"; // Shadow color
    ctx.shadowBlur = 5; // Soft shadow
    ctx.fill();
    ctx.closePath();
}


// Draw paddle
function drawPaddle() {
    ctx.beginPath();
    ctx.rect(paddleX, canvas.height - paddleHeight, paddleWidth, paddleHeight);
    ctx.fillStyle = "#FFFFFF";
    ctx.fill();
    ctx.closePath();
}

// Draw score
function drawScore() {
    ctx.font = "20px Arial"; // Increased font size
    ctx.fillStyle = "#FFFFFF";
    ctx.fillText("Score: " + score, canvas.width - 120, 30); // Adjusted position
}

// Move paddle
function movePaddle() {
    const paddleSpeed = 10; // Increased paddle speed
    if (rightPressed && paddleX < canvas.width - paddleWidth) paddleX += paddleSpeed;
    if (leftPressed && paddleX > 0) paddleX -= paddleSpeed;
}

// Ball-wall collisions
function checkBallWallCollision() {
    if (x + dx > canvas.width - ballRadius || x + dx < ballRadius) dx = -dx;
    if (y + dy < ballRadius) dy = -dy;
    else if (y + dy > canvas.height - ballRadius) {
        if (x > paddleX && x < paddleX + paddleWidth) dy = -dy;
        else endGame();
    }
}

// End game
function endGame() {
    isGameOver = true;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.font = "30px Arial"; // Increased font size
    ctx.fillStyle = "#FF0000";
    ctx.textAlign = "center";
    ctx.fillText("Game Over!", canvas.width / 2, canvas.height / 2);
    ctx.fillStyle = "#FFFFFF";
    ctx.fillText("Your Score: " + score, canvas.width / 2, canvas.height / 2 + 40);

    replayBtn.style.display = "inline-block"; // Show replay button
}

// Replay the game
replayBtn.addEventListener("click", () => {
    initializeGameState();
    draw();
    replayBtn.style.display = "none"; // Hide replay button
});

// Main draw loop
function draw() {
    if (isAnimating || isGameOver) return;

    drawBackground();
    drawBricks();
    drawBall();
    drawPaddle();
    drawScore();
    collisionDetection();
    movePaddle();
    checkBallWallCollision();
    animateDescent();

    x += dx;
    y += dy;

    requestAnimationFrame(draw);
}

// Utility function for rounded rectangles
CanvasRenderingContext2D.prototype.roundRect = function (x, y, w, h, r) {
    if (w < 2 * r) r = w / 2;
    if (h < 2 * r) r = h / 2;
    this.beginPath();
    this.moveTo(x + r, y);
    this.arcTo(x + w, y, x + w, y + h, r);
    this.arcTo(x + w, y + h, x, y + h, r);
    this.arcTo(x, y + h, x, y, r);
    this.arcTo(x, y, x + w, y, r);
    this.closePath();
    return this;
};

// Initialize and start game
initializeGameState();
draw();

function adjustCanvasSize() {
    const isMobile = window.innerWidth <= 600; // Mobile breakpoint
    if (isMobile) {
        canvas.width = window.innerWidth - 20; // Slight padding
        canvas.height = (canvas.width * 2) / 3; // Maintain aspect ratio (e.g., 3:2)
    } else {
        canvas.width = 600; // Restore default desktop size
        canvas.height = 400;
    }
}

adjustCanvasSize();
window.addEventListener("resize", adjustCanvasSize); // Recalculate on window resize

const leftBtn = document.getElementById("leftBtn");
const rightBtn = document.getElementById("rightBtn");

// Add touch event listeners
leftBtn.addEventListener("touchstart", (e) => {
    e.preventDefault(); // Prevent accidental scroll or other touch interactions
    leftPressed = true;
});

leftBtn.addEventListener("touchend", (e) => {
    e.preventDefault();
    leftPressed = false;
});

rightBtn.addEventListener("touchstart", (e) => {
    e.preventDefault();
    rightPressed = true;
});

rightBtn.addEventListener("touchend", (e) => {
    e.preventDefault();
    rightPressed = false;
});
