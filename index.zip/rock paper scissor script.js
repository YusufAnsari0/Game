const playerScoreElem = document.getElementById('playerScore');
const computerScoreElem = document.getElementById('computerScore');
const resultElem = document.getElementById('result');
const popupMessageElem = document.getElementById('popupMessage');
const outcomeScreenElem = document.getElementById('outcomeScreen');

let playerScore = 0;
let computerScore = 0;

const choices = document.querySelectorAll('.choices button');

choices.forEach(choice => {
    choice.addEventListener('click', () => {
        playRound(choice.getAttribute('data-choice'));
    });
});

function playRound(playerChoice) {
    const computerChoice = getComputerChoice();
    const result = determineWinner(playerChoice, computerChoice);
    updateScore(result);
    displayResult(result, playerChoice, computerChoice);
    checkGameOver();
}

function getComputerChoice() {
    const choices = ['rock', 'paper', 'scissors'];
    return choices[Math.floor(Math.random() * choices.length)];
}

function determineWinner(playerChoice, computerChoice) {
    if (playerChoice === computerChoice) return 'draw';
    if (
        (playerChoice === 'rock' && computerChoice === 'scissors') ||
        (playerChoice === 'scissors' && computerChoice === 'paper') ||
        (playerChoice === 'paper' && computerChoice === 'rock')
    ) {
        return 'player';
    }
    return 'computer';
}

function updateScore(result) {
    if (result === 'player') {
        playerScore++;
    } else if (result === 'computer') {
        computerScore++;
    }
}

function displayResult(result, playerChoice, computerChoice) {
    if (result === 'player') {
        resultElem.innerHTML = `Computer chose: ${computerChoice}<br>You Win! ${playerChoice} beats ${computerChoice}.`;
    } else if (result === 'computer') {
        resultElem.innerHTML = `Computer chose: ${computerChoice}<br>You Lose! ${computerChoice} beats ${playerChoice}.`;
    } else {
        resultElem.innerHTML = `Computer chose: ${computerChoice}<br>It's a draw! You both chose ${playerChoice}.`;
    }
    playerScoreElem.textContent = playerScore;
    computerScoreElem.textContent = computerScore;
}

function checkGameOver() {
    if (playerScore === 3 || computerScore === 3) {
        outcomeScreenElem.classList.add('show'); // Show the outcome screen
        popupMessageElem.textContent = playerScore === 3 
            ? 'Congratulations! You won the game!' 
            : 'Game Over! The computer won the game.';
    }
}

function restart() {
    playerScore = 0;
    computerScore = 0;
    playerScoreElem.textContent = playerScore;
    computerScoreElem.textContent = computerScore;
    resultElem.textContent = '';
    outcomeScreenElem.classList.remove('show'); // Hide the outcome screen
}
