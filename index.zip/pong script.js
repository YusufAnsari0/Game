const canvas = document.getElementById('pongCanvas');
const context = canvas.getContext('2d');
const leftScoreElement = document.getElementById('leftScore');
const rightScoreElement = document.getElementById('rightScore');
const messageBox = document.getElementById('messageBox');
const messageText = document.getElementById('messageText');
const startButton = document.getElementById('startBtn');
const pauseButton = document.getElementById('pauseBtn');

const WINNING_SCORE = 5;
const MAX_MISSES = 3;  // Maximum misses allowed before game ends

// Canvas size adjustments
canvas.width = window.innerWidth * 0.95;
canvas.height = window.innerHeight * 0.6;

// Scores
let leftScore = 0;
let rightScore = 0;

// Misses counters
let leftMisses = 0;
let rightMisses = 0;

// Ball properties
let ball = {
    x: canvas.width / 2,
    y: canvas.height / 2,
    radius: 8,
    speed: 3,
    dx: 3,
    dy: 3,
};

// Paddle properties
const paddleWidth = 8;
const paddleHeight = canvas.height / 4;
const paddleSpeed = 6;

let leftPaddle = {
    x: 0,
    y: canvas.height / 2 - paddleHeight / 2,
    width: paddleWidth,
    height: paddleHeight,
    dy: 0,
};

let rightPaddle = {
    x: canvas.width - paddleWidth,
    y: canvas.height / 2 - paddleHeight / 2,
    width: paddleWidth,
    height: paddleHeight,
    dy: 0,
};

// Game state
let isGameRunning = false;
let gameLoopInterval;

// Draw ball
function drawBall() {
    context.beginPath();
    context.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
    context.fillStyle = '#fff';
    context.fill();
    context.closePath();
}

// Draw paddle
function drawPaddle(x, y, width, height) {
    context.fillStyle = '#fff';
    context.fillRect(x, y, width, height);
}

// Move ball
function moveBall() {
    ball.x += ball.dx;
    ball.y += ball.dy;

    // Wall collision (top/bottom)
    if (ball.y + ball.radius > canvas.height || ball.y - ball.radius < 0) {
        ball.dy *= -1;
    }

    // Left player misses the ball
    if (ball.x - ball.radius < 0) {
        rightScore++;
        leftMisses++;
        updateScore();
        if (leftMisses >= MAX_MISSES) {
            displayEndMessage('You Lose!');  // Game ends
        }
        resetBall();
    }

    // Right player misses the ball
    if (ball.x + ball.radius > canvas.width) {
        leftScore++;
        rightMisses++;
        updateScore();
        if (rightMisses >= MAX_MISSES) {
            displayEndMessage('You Win!');  // Game ends
        }
        resetBall();
    }

    // Paddle collision
    if (
        ball.x - ball.radius < leftPaddle.x + leftPaddle.width &&
        ball.y > leftPaddle.y &&
        ball.y < leftPaddle.y + leftPaddle.height
    ) {
        ball.dx *= -1.1;
        ball.dy *= 1.1;
    }

    if (
        ball.x + ball.radius > rightPaddle.x &&
        ball.y > rightPaddle.y &&
        ball.y < rightPaddle.y + rightPaddle.height
    ) {
        ball.dx *= -1.1;
        ball.dy *= 1.1;
    }
}

// Move paddles
function movePaddles() {
    leftPaddle.y += leftPaddle.dy;

    if (leftPaddle.y < 0) leftPaddle.y = 0;
    if (leftPaddle.y + leftPaddle.height > canvas.height) leftPaddle.y = canvas.height - leftPaddle.height;

    if (ball.y < rightPaddle.y + rightPaddle.height / 2) {
        rightPaddle.dy = -paddleSpeed;
    } else {
        rightPaddle.dy = paddleSpeed;
    }

    rightPaddle.y += rightPaddle.dy;

    if (rightPaddle.y < 0) rightPaddle.y = 0;
    if (rightPaddle.y + rightPaddle.height > canvas.height) rightPaddle.y = canvas.height - rightPaddle.height;
}

// Keyboard controls for left paddle
window.addEventListener('keydown', (event) => {
    if (event.key === 'ArrowUp') {
        leftPaddle.dy = -paddleSpeed;
    } else if (event.key === 'ArrowDown') {
        leftPaddle.dy = paddleSpeed;
    }
});

window.addEventListener('keyup', (event) => {
    if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
        leftPaddle.dy = 0;
    }
});

// Update game state
function update() {
    moveBall();
    movePaddles();
}

// Render game objects
function render() {
    context.clearRect(0, 0, canvas.width, canvas.height);
    drawBall();
    drawPaddle(leftPaddle.x, leftPaddle.y, leftPaddle.width, leftPaddle.height);
    drawPaddle(rightPaddle.x, rightPaddle.y, rightPaddle.width, rightPaddle.height);
}

// Game loop
function gameLoop() {
    update();
    render();
    if (!isGameOver()) {
        gameLoopInterval = requestAnimationFrame(gameLoop);
    }
}

// Start the game
function startGame() {
    isGameRunning = true;
    leftMisses = 0;
    rightMisses = 0;
    startButton.disabled = true;
    pauseButton.disabled = false;
    gameLoop();
}

// Pause the game
function pauseGame() {
    isGameRunning = false;
    cancelAnimationFrame(gameLoopInterval);
    startButton.disabled = false;
    pauseButton.disabled = true;
}

// Update score
function updateScore() {
    leftScoreElement.textContent = leftScore;
    rightScoreElement.textContent = rightScore;
}

// Display end game message
function displayEndMessage(message) {
    messageText.textContent = message;
    messageBox.classList.remove('hidden');
    isGameRunning = false;
    startButton.disabled = false;
    pauseButton.disabled = true;
}

// Check if game is over
function isGameOver() {
    return leftMisses >= MAX_MISSES || rightMisses >= MAX_MISSES;
}

// Reset the game
function resetGame() {
    leftScore = 0;
    rightScore = 0;
    leftMisses = 0;
    rightMisses = 0;
    updateScore();
    resetBall();
    messageBox.classList.add('hidden');
    startButton.disabled = false;
    pauseButton.disabled = true;
}

// Reset ball position
function resetBall() {
    ball.x = canvas.width / 2;
    ball.y = canvas.height / 2;
    ball.dx = ball.speed * (Math.random() > 0.5 ? 1 : -1);
    ball.dy = ball.speed * (Math.random() > 0.5 ? 1 : -1);
}

// Gradually increase ball speed
function increaseDifficulty() {
    ball.speed += 0.1;
    ball.dx = ball.dx > 0 ? ball.speed : -ball.speed;
    ball.dy = ball.dy > 0 ? ball.speed : -ball.speed;
}

setInterval(increaseDifficulty, 10000);

// Display end game message
function displayEndMessage(message) {
    messageText.textContent = message;
    creditsText.textContent = "Made By - Yusuf Ansari";  // Add the "Made By - Yusuf" text
    messageBox.classList.remove('hidden');
    isGameRunning = false;
    startButton.disabled = false;
    pauseButton.disabled = true;
}
