document.addEventListener('DOMContentLoaded', () => {
    const numbersBox = document.getElementById('numbersBox');
    const result = document.getElementById('result');
    const popup = document.getElementById('popup');
    let hasPlayed = false; // Ensure the user plays before checking order

    // Generate randomized numbers ensuring they are not initially sorted
    function createNumbers() {
        let numbers;
        do {
            numbers = shuffleArray([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
        } while (isSorted(numbers)); // Re-shuffle if the array is sorted

        numbersBox.innerHTML = ''; // Clear previous numbers
        numbers.forEach(number => {
            const numberElement = document.createElement('div');
            numberElement.classList.add('number');
            numberElement.textContent = number;
            numberElement.draggable = true;
            numberElement.addEventListener('dragstart', handleDragStart);
            numberElement.addEventListener('dragover', handleDragOver);
            numberElement.addEventListener('drop', handleDrop);
            numbersBox.appendChild(numberElement);
        });
        hasPlayed = false; // Reset the "played" state
        result.textContent = ''; // Clear result message
        closePopup(); // Ensure popup is closed
    }

    // Fisher-Yates Shuffle Algorithm for true randomization
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    function handleDragStart(e) {
        e.dataTransfer.setData('text/plain', e.target.textContent);
        e.dataTransfer.effectAllowed = 'move';
        e.target.classList.add('dragging');
    }

    function handleDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
    }

    function handleDrop(e) {
        e.preventDefault();
        const data = e.dataTransfer.getData('text/plain');
        const draggingElement = document.querySelector('.dragging');
        e.target.classList.remove('dragging');
        if (e.target !== draggingElement && e.target.classList.contains('number')) {
            const draggedNumber = draggingElement.textContent;
            draggingElement.textContent = e.target.textContent;
            e.target.textContent = draggedNumber;
            hasPlayed = true; // The user made a move
        }
    }

    // Check if the array is sorted
    function isSorted(numbers) {
        for (let i = 0; i < numbers.length - 1; i++) {
            if (numbers[i] > numbers[i + 1]) {
                return false;
            }
        }
        return true;
    }

    window.checkOrder = function () {
        if (!hasPlayed) {
            result.textContent = "Make a move first!";
            return;
        }

        const numberElements = numbersBox.querySelectorAll('.number');
        const currentOrder = Array.from(numberElements).map(el => parseInt(el.textContent));

        if (isSorted(currentOrder)) {
            result.textContent = "Correct! The numbers are in order.";
            openPopup();
        } else {
            result.textContent = "Incorrect. Try again!";
        }
    };

    window.resetGame = function () {
        result.textContent = ''; // Clear result message
        popup.style.display = 'none'; // Hide popup
        createNumbers(); // Reset numbers
    };

    window.openPopup = function () {
        popup.style.display = 'block';
    };

    window.closePopup = function () {
        popup.style.display = 'none';
    };

    // Initialize the game on page load
    createNumbers();
});
